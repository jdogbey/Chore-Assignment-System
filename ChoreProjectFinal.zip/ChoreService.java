

import java.util.*;


public class ChoreService {
    //intializes the assigned chores to each person and clears the scheduler after 
    public void assignChores(List<Person> people){
        makeSche choreScheduler= new makeSche();
        int days= 7; 

        for (Person person : people){

            for (int i= 0;i<days;i++){  
                String chore = choreScheduler.randChore(person.getName());
                System.out.println("Assigned chore to " + person.getName()+ ": "+ chore);
                person.addChore(chore);
                
                
            }
        }
        choreScheduler.resetAssignedChores();
    }
}

  

  

