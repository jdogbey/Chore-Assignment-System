

import java.util.*;

public class Person{
    
    private List<String> assignedChores= new ArrayList<>();
    private String n;

    //assigns name
    public Person(String name){
        n = name;
    }

    // gets name
    public String getName(){
        return n;
    }


    // adds chore and prints for confirmation
   public void addChore(String chore){
    assignedChores.add(chore);
    System.out.println("Assigned chore: "+ chore);
   }


   // returns list of chores assigned to person
   public List<String> getAssignedChores(){
    return assignedChores;
   }






  


}