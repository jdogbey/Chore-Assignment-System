import java.util.*;

public class User{
    static int numOfPeople;
    static Scanner s= new Scanner(System.in);
    final int SCHEDULE_LENGTH= 28; 

    // start of program's life
    public static void main(String[] args) {
        ChoreService choreService = new ChoreService();
        System.out.println("Welcome to your virtual house chore planner! ");

        System.out.println("\nThe chores this program covers are:\nsweeping,\nmopping,\nvacuuming,\ncleaning kitchen counters,\ntake out the trash,\nemptying the dishwasher,\nwashing the dishes,\ncleaning your room");
    
        System.out.println("\nHow many people does this schedule need to be sufficient for?  (Max 5) ");
        numOfPeople= s.nextInt();
        
        if(numOfPeople >5){
            System.out.println("5 or less people, try again");
            System.exit(0) ;
        }
        s.nextLine();
        
        ArrayList<Person> people= new ArrayList<>();

        for(int i = 0;i < numOfPeople; i++){
            System.out.println("Enter name for person: "+(i+1)+":\n");
            String name = s.nextLine();
            Person p = new Person(name);
            people.add(p);
        }
        
        choreService.assignChores(people);
       
        showShedule(people);
    }


    // displays schedule for each person after all functions are completed 
public static void showShedule(List<Person> people){
    
    for(Person person : people){
        System.out.println("\n"+ person.getName() +"'s schedule: ");
        List<String> chores= person.getAssignedChores();
        for(String chore : chores){
            System.out.println(" - "+ chore);
        }
       
    }
}



 


}