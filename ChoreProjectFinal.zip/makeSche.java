

import java.util.*;

public class makeSche{
    static int numOfPeople = User.numOfPeople;
  
   
    private HashMap<String, Integer> choreFreq = new HashMap<>();
    private HashMap<String, HashMap<String, Integer>> choreLimPerPerson = new HashMap<>();
    private HashSet<String> assignedChores = new HashSet<>();

    
    // Initializes the chore frequencies based on how ofteb they are required to be done
    public makeSche(){
        choreFreq.put("Sweeping", 5);
        choreFreq.put("Mopping", 3);
        choreFreq.put("Vacuuming", 3);
        choreFreq.put("Cleaning kitchen counters", 7);
        choreFreq.put("Take out the trash", 3);
        choreFreq.put("Empty dishwasher", 4);
        choreFreq.put("Washing the dishes", 7);
        choreFreq.put("Clean your room", 3);

        
        for(int i=0; i<numOfPeople; i++){
            HashMap<String, Integer> personChores = new HashMap<>();
            for(String chore : choreFreq.keySet()){
                personChores.put(chore, choreFreq.get(chore));
            }
            choreLimPerPerson.put("Person"+(i+1), personChores);
        }

     
    }

    // Assigns a random chore to the given pereson and ensuring fair distribution
    public String randChore(String personName){
        Random r = new Random();
        
        
        choreLimPerPerson.putIfAbsent(personName, new HashMap<>(choreFreq));
      
        HashMap<String, Integer> personChoresLimit = choreLimPerPerson.get(personName);

        
        List<String> availableChores = new ArrayList<>();
        for(String chore : choreFreq.keySet()){
            if (choreFreq.get(chore) > 0 && personChoresLimit.get(chore) >0){
                availableChores.add(chore);
            }
        }
        
        if(availableChores.isEmpty()){
            resetAssignedChores();
            availableChores.clear();
        }



        if(availableChores.isEmpty()){
        
        System.out.println("No chores available for "+ personName + "after reset.");
        return null;
        
        }

        String chore= availableChores.get(r.nextInt(availableChores.size()));
        assignedChores.add(chore);
        choreFreq.put(chore, choreFreq.get(chore)-1);
        personChoresLimit.put(chore, personChoresLimit.get(chore)-1);
        return chore;


   
    }


    // Resets assigned chores and put the Person's name and chores in the limit hash map
    public void resetAssignedChores(){
        for(String personName : choreLimPerPerson.keySet()){
            HashMap<String, Integer> personChores = new HashMap<>(choreFreq);
            choreLimPerPerson.put(personName, personChores);
        }
        
        assignedChores.clear();
    }

}



   